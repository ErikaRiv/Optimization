-El código "tarea4.py" está dividido por bloques, los cuales son:
 *Importación de librerías
 *Funciones de h(beta,beta0) y su gradiente 
 *Métodos de búsqueda lineal y steepest decent method
 *Error
 *Resultados

Los pasos a seguir para la ejecución son:

1. Abrir
2. Ejecutar por bloques

No se requieren entradas por parte del usuario. Se requiere de los archivos anexos para ejecutar el código. 






Autora
Erika Rivadeneira Pérez - Matemáticas Aplicadas CIMAT