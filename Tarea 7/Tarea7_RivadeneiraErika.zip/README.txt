-El código "tarea7.py" está dividido por bloques, los cuales son:
 *Importación de librerías
 *Funciones de Rosembrock, de Wood de Branin, sus gradientes y sus Hessianos respectivos 
 *Función para método de Dogleg
 *Función para método de Newton-Cauchy Alterno
 *Método de Newton modificado con sus respectivas funciones 
 *Función para imprimir resultados
 *Cálculo de promedio de tiempos de ejecución e iteraciones

Los pasos a seguir para la ejecución son:

1. Abrir
2. Ejecutar por bloques

No se requieren entradas por parte del usuario. Los parámetros necesarios para utilizar cada función se encuentran especificados en el código. 

Se consideró una tolerancia de 1e-4 y un número máximo de iteraciones de 10000 para cada función. 






Autora
Erika Rivadeneira Pérez - Matemáticas Aplicadas CIMAT