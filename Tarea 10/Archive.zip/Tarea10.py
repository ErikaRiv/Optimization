#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Apr 30 21:24:07 2021

@author: erikarivadeneira
"""

import numpy as np
from numpy import linalg as la
from scipy.optimize import line_search

#%%
'''def backtracking(x,f,g):
    alpha = 1
    c1 = 0.0001    #condicion de wolfe
    rho = 0.5
    gk = g(x)
    while f(x+alpha*(-gk))>(f(x)+c1*alpha*np.dot(gk,-gk)): #and alpha>1e-7:
        alpha = rho*alpha 
    return alpha '''

def GCFR(x,f,grad, metodo): #metodo : 1 = 'Polak-Ribiere',2= 'Fletcher- Reeves',3='Hestenes-Stiefel',4='FRPR'
    tol = 1e-4
    xk = x
    gk = grad(xk)
    dk = -gk
    k = 0
    while la.norm(grad)>tol:
        alpha = line_search(f, grad, xk, dk)[0]
        xnew = xk + alpha*dk
        gnew = grad(xnew)
        if metodo == 1:#• Polak-Ribiere
            betaPR = np.dot(gnew,gnew-gk)/np.dot(gk,gk)
            beta = betaPR
        if metodo == 2: #Fletcher- Reeves
            betaFR = np.dot(gnew,gnew)/np.dot(gk,gk)
            beta = betaFR
        if metodo == 3:#Hestenes-Stiefel
            beta = np.dot(gnew,gnew-gk)/np.dot(gnew-gk,dk)
        if metodo == 4: #Fletcher-Reeves Polak-Ribiere
            if betaPR < -betaFR:
                beta = -betaFR
            if abs(betaPR) <= betaFR:
                beta = betaPR
            if betaPR > betaFR:
                beta = betaFR
        dk = -gnew+beta*dk
        #Actualizo
        xk = xnew 
        gk = gnew
        k += 1         
    return xk, k 
        
        
        
