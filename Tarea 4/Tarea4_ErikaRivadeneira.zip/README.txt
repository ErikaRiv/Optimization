-El código "tarea4.py" está dividido por bloques, los cuales son:
 *Importación de librerías
 *Funciones de Rosembrock, Wood y de suavizamiento 
 *Métodos de búsqueda lineal y steepest decent method 
 *Plots para cada función y casos 

Si se requiere utilizar otro valor de lambda en la función de suavizamiento cambiar el valor de la variable "lam" en las funciones "Smooth" y "gSmooth".

Los pasos a seguir para la ejecución son:

1. Abrir
2. Ejecutar por bloques

No se requieren entradas por parte del usuario. Se requiere del archivo txt "y.txt" para ejecutar el código. 

El usuario puede borrar las comillas de las partes comentadas para plotear los resultados deseados.




Autora
Erika Rivadeneira Pérez - Matemáticas Aplicadas CIMAT