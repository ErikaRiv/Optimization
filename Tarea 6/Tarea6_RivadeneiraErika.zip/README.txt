-El código "tarea6.py" está dividido por bloques, los cuales son:
 *Importación de librerías
 *Funciones de Rosembrock de Wood, sus gradientes y sus Hessianos 
 *Solver de sistemas de ecuaciones y Cholesky más la suma de un múltiplo de la identidad
 *Métodos de máximo gradiente, Newton y Newton modificado
 *Resultados

Los pasos a seguir para la ejecución son:

1. Abrir
2. Ejecutar por bloques

No se requieren entradas por parte del usuario. Se requiere de los archivos anexos para ejecutar el código. 






Autora
Erika Rivadeneira Pérez - Matemáticas Aplicadas CIMAT