-El código "tarea7.py" está dividido por bloques, los cuales son:
 *Importación de librerías
 *Funciones que generan Q, b, f y grad(f)
 *Función para método de Barzilai, Gradiente Conjugado y Máximo descenso
 *Función para generar resultados 
 *Gráficas de promedio de gradientes 

Los pasos a seguir para la ejecución son:

1. Abrir
2. Ejecutar por bloques

El programa solamente grafica las normas de los gradientes para número de condición = 6. Si se desea pilotear el resto de número de condiciones en la línea 251 cambiar el argumento Q6 de la función res() por Q2 (condición=2) o Q4 (condición=4) según se requiera.





Autora
Erika Rivadeneira Pérez - Matemáticas Aplicadas CIMAT