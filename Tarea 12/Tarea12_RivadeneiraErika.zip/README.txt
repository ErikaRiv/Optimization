-El script "tarea12.py" está dividido por bloques, los cuales son:
 *Importación de librerías
 *Carga de datos 
 *Funciones sigma, f y g. Función objetivo F y su gradiente aproximado derF
 *Función para método de descenso por gradiente (steepest_des), y BFGS
 *Función para calcular el error
 *Impresión de resultados

Los pasos a seguir para la ejecución son:

1. Abrir
2. Ejecutar 

El programa no requiere entradas del usuario. Se pueden cambiar los valores iniciales de los parámetros en las líneas 182-185.





Autora
Erika Rivadeneira Pérez - Matemáticas Aplicadas CIMAT